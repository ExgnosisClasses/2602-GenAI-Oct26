package com.northwind.triage;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.metadata.DefaultUsage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;

/**
 * A ChatModel that returns canned replies and records every prompt it receives.
 * No network calls, no API key, no cost.
 */
class StubChatModel implements ChatModel {

    private final Deque<String> replies = new ArrayDeque<>();
    private final List<Prompt> received = new ArrayList<>();

    StubChatModel reply(String text) {
        replies.add(text);
        return this;
    }

    List<Prompt> received() {
        return received;
    }

    @Override
    public ChatResponse call(Prompt prompt) {
        received.add(prompt);
        Generation generation = new Generation(new AssistantMessage(replies.removeFirst()));
        ChatResponseMetadata metadata = ChatResponseMetadata.builder()
                .model("gpt-6-luna-2026-09-22")
                .usage(new DefaultUsage(1_000, 200))
                .build();
        return new ChatResponse(List.of(generation), metadata);
    }
}
