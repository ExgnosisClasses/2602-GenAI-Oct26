package com.northwind.triage.guard;

import java.util.List;

import com.northwind.triage.TriageResult;

public record GuardedOutcome(
        String correlationId,
        GuardStatus status,
        TriageResult result,
        List<GuardrailDecision> decisions) {
}
