package com.northwind.triage;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

@Component
public class TriagePrompts {

    private final ResourceLoader resourceLoader;

    public TriagePrompts(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public PromptSet load(String version) {
        return new PromptSet(version, read(version, "system"), read(version, "user"));
    }

    private String read(String version, String role) {
        String location = "classpath:prompts/triage/%s/%s.st".formatted(version, role);
        Resource resource = resourceLoader.getResource(location);
        if (!resource.exists()) {
            throw new IllegalArgumentException("Prompt not found: " + location);
        }
        try {
            return resource.getContentAsString(StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read " + location, e);
        }
    }
}
