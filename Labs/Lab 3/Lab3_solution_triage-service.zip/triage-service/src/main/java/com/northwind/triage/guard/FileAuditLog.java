package com.northwind.triage.guard;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

import org.springframework.stereotype.Component;

/** Appends one line per guardrail decision to a dedicated audit file. */
@Component
public class FileAuditLog implements AuditLog {

    private final Path file;

    public FileAuditLog(GuardrailProperties properties) {
        this.file = Path.of(properties.auditFile());
    }

    @Override
    public synchronized void record(GuardrailDecision decision) {
        try {
            Files.createDirectories(file.toAbsolutePath().getParent());
            Files.writeString(file, decision.toLogLine() + System.lineSeparator(),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write audit log " + file, e);
        }
    }
}
