package com.northwind.triage;

import java.math.BigDecimal;

public record TriageOutcome(
        TriageResult result,
        String promptVersion,
        String reasoningEffort,
        String model,
        long inputTokens,
        long cachedTokens,
        long outputTokens,
        long reasoningTokens,
        long latencyMs,
        BigDecimal costUsd) {
}
