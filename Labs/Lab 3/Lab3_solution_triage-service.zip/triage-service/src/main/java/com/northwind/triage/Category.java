package com.northwind.triage;

public enum Category { CARD, ACCOUNT_ACCESS, PAYMENTS, MORTGAGE, FRAUD, OTHER }
