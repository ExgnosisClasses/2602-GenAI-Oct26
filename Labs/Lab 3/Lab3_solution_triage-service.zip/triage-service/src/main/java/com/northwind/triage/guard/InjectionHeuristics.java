package com.northwind.triage.guard;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

/** Free, fast first-pass check for well-known injection phrases. Easy to evade, so it is never the only check. */
@Component
public class InjectionHeuristics {

    private static final List<Pattern> PATTERNS = List.of(
            Pattern.compile("(?i)ignore (all |any )?(of )?(the |your )?(previous |prior |above |earlier )?instructions"),
            Pattern.compile("(?i)ignorez (toutes )?(vos|les) instructions"),
            Pattern.compile("(?i)system prompt"),
            Pattern.compile("(?i)</?customer_message>"),
            Pattern.compile("(?im)^\\s*(system|assistant)\\s*:"));

    public Optional<String> match(String text) {
        return PATTERNS.stream()
                .filter(p -> p.matcher(text).find())
                .map(Pattern::pattern)
                .findFirst();
    }
}
