package com.northwind.triage.guard;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

/** Model-based input check: topic classification and prompt-injection detection in one low-cost call. */
@Component
public class InputScreen {

    private final ChatClient chatClient;
    private final String instructions;

    public InputScreen(ChatClient.Builder builder, ResourceLoader resourceLoader) {
        this.chatClient = builder.build();
        try {
            this.instructions = resourceLoader.getResource("classpath:prompts/guardrails/input-screen.st")
                    .getContentAsString(StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public ScreeningResult screen(String maskedMessage) {
        return chatClient.prompt()
                .system(instructions)
                .user(u -> u.text("""
                                <customer_message>
                                {message}
                                </customer_message>
                                """)
                        .param("message", maskedMessage))
                .options(OpenAiChatOptions.builder().reasoningEffort("low"))
                .call()
                .entity(ScreeningResult.class);
    }
}
