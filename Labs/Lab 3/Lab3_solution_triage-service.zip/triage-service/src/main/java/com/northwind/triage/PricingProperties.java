package com.northwind.triage;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("pricing")
public record PricingProperties(Map<String, ModelPrice> models) {

    public record ModelPrice(BigDecimal inputPerMillion,
                             BigDecimal cachedInputPerMillion,
                             BigDecimal outputPerMillion) {
    }
}
