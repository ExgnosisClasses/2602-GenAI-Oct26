package com.northwind.triage.guard;

@FunctionalInterface
public interface AuditLog {

    void record(GuardrailDecision decision);
}
