package com.northwind.triage;

public record TriageResult(
        Category category,
        Urgency urgency,
        String summary,
        String suggestedReply) {
}
