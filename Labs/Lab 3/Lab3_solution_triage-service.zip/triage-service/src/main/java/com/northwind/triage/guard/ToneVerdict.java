package com.northwind.triage.guard;

public record ToneVerdict(
        boolean polite,
        boolean plainLanguage,
        boolean sameLanguage,
        boolean noAdvice,
        String reason) {

    public boolean pass() {
        return polite && plainLanguage && sameLanguage && noAdvice;
    }
}
