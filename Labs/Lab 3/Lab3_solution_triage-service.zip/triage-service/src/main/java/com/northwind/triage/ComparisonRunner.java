package com.northwind.triage;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
@Profile("compare")
public class ComparisonRunner implements CommandLineRunner {

    record Example(String message, Category category, Urgency urgency) {
    }

    private final TriageService triageService;

    public ComparisonRunner(TriageService triageService) {
        this.triageService = triageService;
    }

    @Override
    public void run(String... args) throws IOException {
        List<Example> examples = loadExamples();
        System.out.printf("%nComparing on %d labelled messages%n%n", examples.size());
        System.out.printf("%-7s %-7s %9s %9s %8s %12s %10s%n",
                "Prompt", "Effort", "Category", "Urgency", "Avg ms", "Avg out tok", "Total USD");

        for (String version : List.of("v1", "v2")) {
            for (String effort : List.of("low", "medium")) {
                evaluate(examples, version, effort);
            }
        }
    }

    private void evaluate(List<Example> examples, String version, String effort) {
        int categoryHits = 0;
        int urgencyHits = 0;
        long totalMs = 0;
        long totalOutputTokens = 0;
        BigDecimal totalCost = BigDecimal.ZERO;

        for (Example example : examples) {
            TriageOutcome outcome = triageService.triage(example.message(), version, effort);
            if (outcome.result().category() == example.category()) categoryHits++;
            if (outcome.result().urgency() == example.urgency()) urgencyHits++;
            totalMs += outcome.latencyMs();
            totalOutputTokens += outcome.outputTokens();
            totalCost = totalCost.add(outcome.costUsd());
        }

        int n = examples.size();
        System.out.printf("%-7s %-7s %8d%% %8d%% %8d %12d %10s%n",
                version, effort,
                100 * categoryHits / n, 100 * urgencyHits / n,
                totalMs / n, totalOutputTokens / n,
                totalCost.setScale(5, RoundingMode.HALF_UP).toPlainString());
    }

    private List<Example> loadExamples() throws IOException {
        String content = new ClassPathResource("eval/triage-examples.txt")
                .getContentAsString(StandardCharsets.UTF_8);
        return content.lines()
                .filter(line -> !line.isBlank() && !line.startsWith("#"))
                .map(line -> line.split("\\|"))
                .map(p -> new Example(p[0].trim(), Category.valueOf(p[1].trim()), Urgency.valueOf(p[2].trim())))
                .toList();
    }
}
