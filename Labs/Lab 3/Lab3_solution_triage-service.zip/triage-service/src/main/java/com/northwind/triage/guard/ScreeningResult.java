package com.northwind.triage.guard;

public record ScreeningResult(Topic topic, boolean injectionAttempt, String reason) {
}
