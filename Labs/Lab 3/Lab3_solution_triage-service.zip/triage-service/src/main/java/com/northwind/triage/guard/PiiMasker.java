package com.northwind.triage.guard;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

/**
 * Input guardrail: replaces personal and account data with typed placeholders
 * before any text is sent to a model or written to a log.
 */
@Component
public class PiiMasker {

    /** Transit (5) - institution (3) - account (7 to 12 digits), the Canadian cheque format. */
    private static final Pattern ACCOUNT_FORMATTED = Pattern.compile("\\b\\d{5}[ -]\\d{3}[ -]\\d{7,12}\\b");

    /** 13 to 19 digits, optionally grouped with spaces or dashes. */
    private static final Pattern CARD = Pattern.compile("\\b(?:\\d[ -]?){12,18}\\d\\b");

    /** "account 1234567", "acct #: 1234-567", "numéro de compte 1234567" and similar. */
    private static final Pattern ACCOUNT_LABELLED = Pattern.compile(
            "(?i)\\b(account|acct|compte)(\\s+(number|no\\.?|num[ée]ro))?\\s*[:#]?\\s*(\\d[\\d -]{5,14}\\d)");

    /** Canadian Social Insurance Number: nine digits, valid only if it passes the Luhn check. */
    private static final Pattern SIN = Pattern.compile("\\b\\d{3}[ -]?\\d{3}[ -]?\\d{3}\\b");

    private static final Pattern EMAIL = Pattern.compile("[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+");

    /** North American phone numbers: 613-555-0123, (613) 555-0123, +1 613 555 0123. */
    private static final Pattern PHONE = Pattern.compile(
            "(?<!\\d)(?:\\+?1[ .-]?)?\\(?\\d{3}\\)?[ .-]?\\d{3}[ .-]?\\d{4}(?!\\d)");

    public MaskingResult mask(String text) {
        Set<String> found = new TreeSet<>();
        String out = replace(ACCOUNT_FORMATTED, text, "ACCOUNT_NUMBER", s -> true, found);
        out = replace(CARD, out, "CARD_NUMBER", s -> true, found);
        out = maskLabelledAccounts(out, found);
        out = replace(SIN, out, "SIN", PiiMasker::luhnValid, found);
        out = replace(EMAIL, out, "EMAIL", s -> true, found);
        out = replace(PHONE, out, "PHONE", s -> true, found);
        return new MaskingResult(out, Collections.unmodifiableSet(found));
    }

    private static String replace(Pattern pattern, String text, String label,
                                  Predicate<String> check, Set<String> found) {
        return pattern.matcher(text).replaceAll(m -> {
            if (check.test(m.group())) {
                found.add(label);
                return "[" + label + "]";
            }
            return Matcher.quoteReplacement(m.group());
        });
    }

    private static String maskLabelledAccounts(String text, Set<String> found) {
        return ACCOUNT_LABELLED.matcher(text).replaceAll(m -> {
            found.add("ACCOUNT_NUMBER");
            String masked = m.group().replace(m.group(4), "[ACCOUNT_NUMBER]");
            return Matcher.quoteReplacement(masked);
        });
    }

    static boolean luhnValid(String candidate) {
        String digits = candidate.replaceAll("\\D", "");
        int sum = 0;
        for (int i = 0; i < digits.length(); i++) {
            int d = digits.charAt(digits.length() - 1 - i) - '0';
            if (i % 2 == 1) {
                d *= 2;
                if (d > 9) {
                    d -= 9;
                }
            }
            sum += d;
        }
        return sum % 10 == 0;
    }
}
