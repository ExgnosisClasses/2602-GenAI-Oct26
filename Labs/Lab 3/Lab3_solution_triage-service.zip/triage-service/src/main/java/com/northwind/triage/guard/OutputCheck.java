package com.northwind.triage.guard;

import java.util.List;

public record OutputCheck(List<String> problems) {

    public boolean pass() {
        return problems.isEmpty();
    }

    public String summary() {
        return String.join("; ", problems);
    }
}
