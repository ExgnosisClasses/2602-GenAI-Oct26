package com.northwind.triage.guard;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/triage/guarded")
public class GuardedTriageController {

    public record GuardedRequest(String message) {
    }

    private final GuardedTriageService guardedTriageService;
    private final String defaultVersion;
    private final String defaultEffort;

    public GuardedTriageController(GuardedTriageService guardedTriageService,
                                   @Value("${triage.prompt-version}") String defaultVersion,
                                   @Value("${triage.reasoning-effort}") String defaultEffort) {
        this.guardedTriageService = guardedTriageService;
        this.defaultVersion = defaultVersion;
        this.defaultEffort = defaultEffort;
    }

    @PostMapping
    public GuardedOutcome triage(@RequestBody GuardedRequest request,
                                 @RequestParam(required = false) String version,
                                 @RequestParam(required = false) String effort) {
        return guardedTriageService.triage(
                request.message(),
                version != null ? version : defaultVersion,
                effort != null ? effort : defaultEffort);
    }
}
