package com.northwind.triage.guard;

import java.util.Set;

public record MaskingResult(String text, Set<String> maskedTypes) {

    public boolean masked() {
        return !maskedTypes.isEmpty();
    }
}
