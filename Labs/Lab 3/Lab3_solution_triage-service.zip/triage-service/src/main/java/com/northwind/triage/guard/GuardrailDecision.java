package com.northwind.triage.guard;

import java.time.Instant;

/** One guardrail decision, as written to the audit log. Never contains raw customer data. */
public record GuardrailDecision(
        Instant timestamp,
        String correlationId,
        String guardrail,
        String decision,
        String detail) {

    public String toLogLine() {
        return "%s correlationId=%s guardrail=%s decision=%s detail=\"%s\""
                .formatted(timestamp, correlationId, guardrail, decision, detail);
    }
}
