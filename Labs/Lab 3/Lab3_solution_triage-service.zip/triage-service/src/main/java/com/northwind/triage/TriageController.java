package com.northwind.triage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/triage")
public class TriageController {

    public record TriageRequest(String message) {
    }

    private final TriageService triageService;
    private final String defaultVersion;
    private final String defaultEffort;

    public TriageController(TriageService triageService,
                            @Value("${triage.prompt-version}") String defaultVersion,
                            @Value("${triage.reasoning-effort}") String defaultEffort) {
        this.triageService = triageService;
        this.defaultVersion = defaultVersion;
        this.defaultEffort = defaultEffort;
    }

    @PostMapping
    public TriageOutcome triage(@RequestBody TriageRequest request,
                                @RequestParam(required = false) String version,
                                @RequestParam(required = false) String effort) {
        return triageService.triage(
                request.message(),
                version != null ? version : defaultVersion,
                effort != null ? effort : defaultEffort);
    }
}
