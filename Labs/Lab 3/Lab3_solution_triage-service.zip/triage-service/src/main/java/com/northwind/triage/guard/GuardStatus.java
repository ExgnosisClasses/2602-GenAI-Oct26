package com.northwind.triage.guard;

public enum GuardStatus {
    /** Passed every guardrail; the suggested reply can be used. */
    ALLOWED,
    /** Stopped by an input guardrail; the reply is an approved standard message. */
    BLOCKED,
    /** Needs a person to review before anything is sent to the customer. */
    ESCALATED
}
