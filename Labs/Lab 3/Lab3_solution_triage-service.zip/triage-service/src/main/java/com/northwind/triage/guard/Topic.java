package com.northwind.triage.guard;

public enum Topic {
    BANKING_SERVICE,
    GENERAL_QUESTION,
    INVESTMENT_ADVICE,
    TAX_OR_LEGAL_ADVICE,
    OTHER_CUSTOMER_INFORMATION;

    public boolean denied() {
        return this == INVESTMENT_ADVICE || this == TAX_OR_LEGAL_ADVICE || this == OTHER_CUSTOMER_INFORMATION;
    }
}
