package com.northwind.triage;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class CostCalculator {

    private static final BigDecimal MILLION = BigDecimal.valueOf(1_000_000);

    private final PricingProperties pricing;

    public CostCalculator(PricingProperties pricing) {
        this.pricing = pricing;
    }

    /**
     * Cost in USD for one call. The response may report a dated snapshot name
     * (for example gpt-6-luna-2026-09-22), so prices are matched by the longest
     * configured model name that the reported name starts with.
     */
    public BigDecimal cost(String model, long promptTokens, long cachedTokens, long completionTokens) {
        PricingProperties.ModelPrice price = findPrice(model);
        long uncached = promptTokens - cachedTokens;
        return price.inputPerMillion().multiply(BigDecimal.valueOf(uncached))
                .add(price.cachedInputPerMillion().multiply(BigDecimal.valueOf(cachedTokens)))
                .add(price.outputPerMillion().multiply(BigDecimal.valueOf(completionTokens)))
                .divide(MILLION, 8, RoundingMode.HALF_UP);
    }

    private PricingProperties.ModelPrice findPrice(String model) {
        return pricing.models().entrySet().stream()
                .filter(e -> model != null && model.startsWith(e.getKey()))
                .max(Comparator.comparingInt(e -> e.getKey().length()))
                .map(Map.Entry::getValue)
                .orElseThrow(() -> new IllegalStateException("No price configured for model " + model));
    }
}
