package com.northwind.triage.guard;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("guardrails")
public record GuardrailProperties(
        int maxInputChars,
        String auditFile,
        String disclaimer,
        String referralReply,
        String fallbackReply) {
}
