package com.northwind.triage;

public enum Urgency { LOW, MEDIUM, HIGH }
