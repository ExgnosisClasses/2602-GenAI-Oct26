package com.northwind.triage;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.stereotype.Service;

@Service
public class TriageService {

    private static final Logger log = LoggerFactory.getLogger(TriageService.class);

    private final ChatClient chatClient;
    private final TriagePrompts prompts;
    private final CostCalculator costCalculator;
    private final BeanOutputConverter<TriageResult> converter = new BeanOutputConverter<>(TriageResult.class);

    public TriageService(ChatClient.Builder builder, TriagePrompts prompts, CostCalculator costCalculator) {
        this.chatClient = builder.build();
        this.prompts = prompts;
        this.costCalculator = costCalculator;
    }

    public TriageOutcome triage(String message, String promptVersion, String reasoningEffort) {
        return triage(message, promptVersion, reasoningEffort, null);
    }

    /**
     * Triage with an optional revision note, used by the output guardrail's retry.
     * The note goes into the system message, never inside the customer_message tags.
     */
    public TriageOutcome triage(String message, String promptVersion, String reasoningEffort, String revisionNote) {
        PromptSet prompt = prompts.load(promptVersion);
        String system = revisionNote == null
                ? prompt.system()
                : prompt.system() + "\n\nRevision required: " + revisionNote.replace("{", "(").replace("}", ")");

        long start = System.nanoTime();
        ChatResponse response = chatClient.prompt()
                .system(system)
                .user(u -> u.text(prompt.user())
                        .param("message", message)
                        .param("format", converter.getFormat()))
                .options(OpenAiChatOptions.builder().reasoningEffort(reasoningEffort))
                .call()
                .chatResponse();
        long latencyMs = (System.nanoTime() - start) / 1_000_000;

        TriageResult result = converter.convert(response.getResult().getOutput().getText());

        Usage usage = response.getMetadata().getUsage();
        String model = response.getMetadata().getModel();
        long inputTokens = usage.getPromptTokens();
        long outputTokens = usage.getCompletionTokens();
        long cachedTokens = usage.getCacheReadInputTokens() == null ? 0 : usage.getCacheReadInputTokens();
        long reasoningTokens = reasoningTokens(usage);
        BigDecimal cost = costCalculator.cost(model, inputTokens, cachedTokens, outputTokens);

        log.info("triage promptVersion={} effort={} model={} inputTokens={} cachedTokens={} outputTokens={} "
                        + "reasoningTokens={} latencyMs={} costUsd={} category={} urgency={}",
                promptVersion, reasoningEffort, model, inputTokens, cachedTokens, outputTokens,
                reasoningTokens, latencyMs, cost.toPlainString(), result.category(), result.urgency());

        return new TriageOutcome(result, promptVersion, reasoningEffort, model,
                inputTokens, cachedTokens, outputTokens, reasoningTokens, latencyMs, cost);
    }

    private static long reasoningTokens(Usage usage) {
        if (usage.getNativeUsage() instanceof com.openai.models.completions.CompletionUsage nativeUsage) {
            return nativeUsage.completionTokensDetails()
                    .flatMap(details -> details.reasoningTokens())
                    .orElse(0L);
        }
        return 0L;
    }
}
