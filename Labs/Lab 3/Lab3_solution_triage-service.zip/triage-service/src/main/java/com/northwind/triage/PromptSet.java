package com.northwind.triage;

public record PromptSet(String version, String system, String user) {
}
