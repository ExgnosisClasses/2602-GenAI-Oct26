package com.northwind.triage.guard;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.northwind.triage.Category;
import com.northwind.triage.TriageResult;
import com.northwind.triage.TriageService;
import com.northwind.triage.Urgency;

/**
 * Runs the layered controls around the triage model call:
 * input limit, PII masking, injection heuristics, topic and injection screening,
 * triage, output guardrail with one retry, required disclaimer, and an audit record for every decision.
 */
@Service
public class GuardedTriageService {

    private final TriageService triageService;
    private final PiiMasker piiMasker;
    private final InjectionHeuristics injectionHeuristics;
    private final InputScreen inputScreen;
    private final OutputGuardrail outputGuardrail;
    private final AuditLog auditLog;
    private final GuardrailProperties properties;

    public GuardedTriageService(TriageService triageService, PiiMasker piiMasker,
                                InjectionHeuristics injectionHeuristics, InputScreen inputScreen,
                                OutputGuardrail outputGuardrail, AuditLog auditLog,
                                GuardrailProperties properties) {
        this.triageService = triageService;
        this.piiMasker = piiMasker;
        this.injectionHeuristics = injectionHeuristics;
        this.inputScreen = inputScreen;
        this.outputGuardrail = outputGuardrail;
        this.auditLog = auditLog;
        this.properties = properties;
    }

    public GuardedOutcome triage(String message, String promptVersion, String reasoningEffort) {
        String id = UUID.randomUUID().toString();
        List<GuardrailDecision> decisions = new ArrayList<>();

        // 1. Input limit
        if (message.length() > properties.maxInputChars()) {
            decide(decisions, id, "input-limit", "BLOCK", "message has " + message.length() + " characters");
            TriageResult reply = standardReply(decisions, id, properties.fallbackReply());
            return new GuardedOutcome(id, GuardStatus.BLOCKED, reply, decisions);
        }
        decide(decisions, id, "input-limit", "PASS", "");

        // 2. PII masking: from here on, only the masked text is used
        MaskingResult masking = piiMasker.mask(message);
        String masked = masking.text();
        decide(decisions, id, "pii-masking", masking.masked() ? "MASK" : "PASS", String.join(",", masking.maskedTypes()));

        // 3. Injection heuristics (free) and model screening (topic + injection)
        Optional<String> heuristic = injectionHeuristics.match(masked);
        ScreeningResult screening = inputScreen.screen(masked);

        if (screening.topic().denied()) {
            decide(decisions, id, "denied-topic", "BLOCK", screening.topic().name());
            TriageResult reply = standardReply(decisions, id, properties.referralReply());
            return new GuardedOutcome(id, GuardStatus.BLOCKED, reply, decisions);
        }
        decide(decisions, id, "denied-topic", "PASS", screening.topic().name());

        boolean injection = heuristic.isPresent() || screening.injectionAttempt();
        decide(decisions, id, "prompt-injection", injection ? "FLAG" : "PASS",
                heuristic.map(p -> "heuristic").orElse(screening.injectionAttempt() ? "screen" : ""));

        // 4. Triage on masked text
        TriageResult result = triageService.triage(masked, promptVersion, reasoningEffort).result();

        // 5. Output guardrail with one automatic retry
        GuardStatus status = injection ? GuardStatus.ESCALATED : GuardStatus.ALLOWED;
        OutputCheck check = outputGuardrail.check(masked, result);
        if (!check.pass()) {
            decide(decisions, id, "output", "RETRY", check.summary());
            result = triageService.triage(masked, promptVersion, reasoningEffort,
                    "Your previous suggested reply was rejected: " + check.summary()
                            + ". Write a new reply that fixes these problems.").result();
            check = outputGuardrail.check(masked, result);
        }
        if (check.pass()) {
            decide(decisions, id, "output", "PASS", "");
        } else {
            decide(decisions, id, "output", "ESCALATE", check.summary());
            result = new TriageResult(result.category(), result.urgency(), result.summary(), properties.fallbackReply());
            status = GuardStatus.ESCALATED;
        }

        // 6. Required disclaimer, added in code
        result = outputGuardrail.withDisclaimer(result);
        decide(decisions, id, "disclaimer", "APPLY", "");

        return new GuardedOutcome(id, status, result, decisions);
    }

    private TriageResult standardReply(List<GuardrailDecision> decisions, String id, String reply) {
        decide(decisions, id, "disclaimer", "APPLY", "");
        return outputGuardrail.withDisclaimer(new TriageResult(Category.OTHER, Urgency.LOW,
                "Handled by a standard response.", reply));
    }

    private void decide(List<GuardrailDecision> decisions, String id, String guardrail, String decision, String detail) {
        GuardrailDecision d = new GuardrailDecision(Instant.now(), id, guardrail, decision, detail);
        decisions.add(d);
        auditLog.record(d);
    }
}
