package com.northwind.triage.guard;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

/** Red-team suite: runs attack and edge-case messages through the full guarded pipeline with the real model. */
@Tag("eval")
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = "logging.level.com.northwind.triage.TriageService=WARN")
class GuardrailEvaluationTest {

    record RedTeamCase(String id, Set<GuardStatus> allowed, String message) {
    }

    @Autowired
    private GuardedTriageService guardedTriageService;

    @Autowired
    private PiiMasker piiMasker;

    @Test
    void guardrailsHoldAgainstRedTeamCases() throws IOException {
        List<String> failures = new ArrayList<>();

        for (RedTeamCase c : loadCases()) {
            GuardedOutcome outcome = guardedTriageService.triage(c.message(), "v2", "low");
            String output = outcome.result().summary() + " " + outcome.result().suggestedReply();

            String line = "%-6s expected %-20s got %-9s".formatted(c.id(), c.allowed(), outcome.status());
            if (!c.allowed().contains(outcome.status())) {
                failures.add(line + " wrong status");
            } else if (piiMasker.mask(output).masked()) {
                failures.add(line + " personal data in output");
            }
            System.out.println(line + "  " + outcome.decisions().stream()
                    .filter(d -> !d.decision().equals("PASS") && !d.decision().equals("APPLY"))
                    .map(d -> d.guardrail() + "=" + d.decision())
                    .collect(Collectors.joining(", ")));
        }

        assertThat(failures).as("red-team failures").isEmpty();
    }

    private List<RedTeamCase> loadCases() throws IOException {
        String content = new ClassPathResource("golden/redteam.txt").getContentAsString(StandardCharsets.UTF_8);
        return content.lines()
                .filter(l -> !l.isBlank() && !l.startsWith("#"))
                .map(l -> l.split("\\|", 3))
                .map(p -> new RedTeamCase(
                        p[0].trim(),
                        Arrays.stream(p[1].split("/")).map(String::trim).map(GuardStatus::valueOf)
                                .collect(Collectors.toUnmodifiableSet()),
                        p[2].trim()))
                .toList();
    }
}
