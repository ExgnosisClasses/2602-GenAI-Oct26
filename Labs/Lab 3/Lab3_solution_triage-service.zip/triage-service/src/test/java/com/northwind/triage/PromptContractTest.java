package com.northwind.triage;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.core.io.DefaultResourceLoader;

class PromptContractTest {

    private final TriagePrompts prompts = new TriagePrompts(new DefaultResourceLoader());

    @ParameterizedTest
    @ValueSource(strings = {"v1", "v2"})
    void userTemplatesContainRequiredPlaceholders(String version) {
        assertThat(prompts.load(version).user())
                .contains("{message}")
                .contains("{format}");
    }

    @ParameterizedTest
    @EnumSource(Category.class)
    void v2SystemPromptDefinesEveryCategory(Category category) {
        assertThat(prompts.load("v2").system()).contains("- " + category.name() + ":");
    }

    @ParameterizedTest
    @EnumSource(Urgency.class)
    void v2SystemPromptDefinesEveryUrgency(Urgency urgency) {
        assertThat(prompts.load("v2").system()).contains("- " + urgency.name() + ":");
    }
}
