package com.northwind.triage.eval;

public record Score(String scorer, boolean pass, String detail) {

    public static Score pass(String scorer) {
        return new Score(scorer, true, "");
    }

    public static Score fail(String scorer, String detail) {
        return new Score(scorer, false, detail);
    }
}
