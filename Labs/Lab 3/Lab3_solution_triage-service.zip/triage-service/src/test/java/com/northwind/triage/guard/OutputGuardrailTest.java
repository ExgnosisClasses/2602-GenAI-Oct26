package com.northwind.triage.guard;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.core.io.DefaultResourceLoader;

import com.northwind.triage.Category;
import com.northwind.triage.StubChatModel;
import com.northwind.triage.TriageResult;
import com.northwind.triage.Urgency;

class OutputGuardrailTest {

    static final GuardrailProperties PROPERTIES = new GuardrailProperties(
            2000, "target/test-audit.log",
            "This reply was prepared with automated assistance.",
            "An advisor will contact you.",
            "A member of our team will follow up.");

    static final String TONE_PASS = """
            {"polite":true,"plainLanguage":true,"sameLanguage":true,"noAdvice":true,"reason":"Fine."}
            """;

    private final StubChatModel model = new StubChatModel();
    private final OutputGuardrail guardrail = new OutputGuardrail(
            ChatClient.builder(model), new DefaultResourceLoader(), new PiiMasker(), PROPERTIES);

    private static TriageResult reply(String text) {
        return new TriageResult(Category.PAYMENTS, Urgency.LOW, "Fee question.", text);
    }

    @Test
    void passesACleanReplyAfterTheToneCheck() {
        model.reply(TONE_PASS);

        OutputCheck check = guardrail.check("Why was I charged a fee?", reply("An agent will review the fee with you."));

        assertThat(check.pass()).isTrue();
        assertThat(model.received()).hasSize(1);   // the tone check ran
    }

    @Test
    void rejectsCommitmentsWithoutCallingTheModel() {
        OutputCheck check = guardrail.check("Why was I charged a fee?", reply("We will refund the fee today."));

        assertThat(check.pass()).isFalse();
        assertThat(check.summary()).contains("promises an outcome");
        assertThat(model.received()).isEmpty();    // cheap rules failed first; no tone check
    }

    @Test
    void rejectsExclamationMarksAndPersonalData() {
        assertThat(guardrail.check("hi", reply("Great news! We fixed it.")).summary())
                .contains("exclamation");
        assertThat(guardrail.check("hi", reply("Your card 4111 1111 1111 1111 is blocked.")).summary())
                .contains("personal or account data");
    }

    @Test
    void appendsTheDisclaimerExactlyOnce() {
        TriageResult once = guardrail.withDisclaimer(reply("An agent will call you."));
        TriageResult twice = guardrail.withDisclaimer(once);

        assertThat(once.suggestedReply()).endsWith(PROPERTIES.disclaimer());
        assertThat(twice.suggestedReply()).isEqualTo(once.suggestedReply());
    }
}
