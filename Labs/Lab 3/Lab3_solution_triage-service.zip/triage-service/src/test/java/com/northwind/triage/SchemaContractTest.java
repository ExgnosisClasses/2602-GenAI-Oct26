package com.northwind.triage;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.core.io.ClassPathResource;

class SchemaContractTest {

    private static final Path SNAPSHOT = Path.of("src/test/resources/contracts/triage-result-schema.json");

    private final BeanOutputConverter<TriageResult> converter = new BeanOutputConverter<>(TriageResult.class);

    @Test
    void schemaMatchesApprovedSnapshot() throws IOException {
        String schema = converter.getJsonSchema();
        if (Files.notExists(SNAPSHOT)) {
            Files.createDirectories(SNAPSHOT.getParent());
            Files.writeString(SNAPSHOT, schema);
            fail("Snapshot created at " + SNAPSHOT + ". Review it, then run the tests again.");
        }
        assertThat(schema).isEqualToIgnoringWhitespace(Files.readString(SNAPSHOT));
    }

    @ParameterizedTest
    @ValueSource(strings = {"fixtures/card-high.json", "fixtures/branch-hours.json", "fixtures/fraud-french.json"})
    void recordedModelResponsesStillParse(String fixture) throws IOException {
        String json = new ClassPathResource(fixture).getContentAsString(StandardCharsets.UTF_8);

        TriageResult result = converter.convert(json);

        assertThat(result.category()).isNotNull();
        assertThat(result.urgency()).isNotNull();
        assertThat(result.summary()).isNotBlank();
        assertThat(result.suggestedReply()).isNotBlank();
    }
}
