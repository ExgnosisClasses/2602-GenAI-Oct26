package com.northwind.triage.eval;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;

import org.junit.jupiter.api.Test;

import com.northwind.triage.Category;
import com.northwind.triage.TriageResult;
import com.northwind.triage.Urgency;

class RuleScorersTest {

    private final GoldenCase lostCard = new GoldenCase(
            "T-1", Set.of("common"), Category.CARD, Urgency.HIGH, "I lost my card");

    private static TriageResult result(Category category, Urgency urgency, String reply) {
        return new TriageResult(category, urgency, "summary", reply);
    }

    @Test
    void categoryAndUrgencyUseExactMatch() {
        TriageResult right = result(Category.CARD, Urgency.HIGH, "We can help.");
        TriageResult wrong = result(Category.OTHER, Urgency.LOW, "We can help.");

        assertThat(RuleScorers.category().score(lostCard, right).pass()).isTrue();
        assertThat(RuleScorers.urgency().score(lostCard, wrong).pass()).isFalse();
    }

    @Test
    void detectsCardNumbersInTheReply() {
        TriageResult leaky = result(Category.CARD, Urgency.HIGH, "Your card 4519 0300 1234 5678 is blocked.");
        TriageResult safe = result(Category.CARD, Urgency.HIGH, "Your card ending in 5678 is blocked.");

        assertThat(RuleScorers.noCardNumbers().score(lostCard, leaky).pass()).isFalse();
        assertThat(RuleScorers.noCardNumbers().score(lostCard, safe).pass()).isTrue();
    }

    @Test
    void detectsCommitmentsAboutOutcomes() {
        TriageResult promise = result(Category.PAYMENTS, Urgency.LOW, "We will refund the fee today.");
        TriageResult neutral = result(Category.PAYMENTS, Urgency.LOW, "An agent will review the fee with you.");

        assertThat(RuleScorers.noCommitments().score(lostCard, promise).pass()).isFalse();
        assertThat(RuleScorers.noCommitments().score(lostCard, neutral).pass()).isTrue();
    }
}
