package com.northwind.triage.eval;

import com.northwind.triage.TriageResult;

public interface Scorer {

    Score score(GoldenCase goldenCase, TriageResult result);
}
