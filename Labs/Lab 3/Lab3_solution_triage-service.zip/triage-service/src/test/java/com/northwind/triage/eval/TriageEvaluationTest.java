package com.northwind.triage.eval;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.northwind.triage.TriageResult;
import com.northwind.triage.TriageService;

@Tag("eval")
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = "logging.level.com.northwind.triage.TriageService=WARN")
class TriageEvaluationTest {

    private static final String PROMPT_VERSION = System.getProperty("prompt.version", "v2");
    private static final String REASONING_EFFORT = "low";
    private static final double MIN_PASS_RATE = 0.85;

    @Autowired
    private TriageService triageService;

    @Autowired
    private ChatClient.Builder chatClientBuilder;

    @Test
    void promptIsFitForRelease() throws IOException {
        List<GoldenCase> cases = GoldenDataset.load("golden/triage-golden.txt");
        String rubric = new ClassPathResource("judge/reply-judge.st").getContentAsString(StandardCharsets.UTF_8);

        List<Scorer> scorers = new ArrayList<>(RuleScorers.all());
        scorers.add(new ReplyJudge(chatClientBuilder, rubric));

        List<CaseResult> results = new ArrayList<>();
        for (GoldenCase goldenCase : cases) {
            TriageResult result = triageService.triage(goldenCase.message(), PROMPT_VERSION, REASONING_EFFORT).result();
            List<Score> scores = scorers.stream().map(s -> s.score(goldenCase, result)).toList();
            results.add(new CaseResult(goldenCase, scores));
        }

        EvaluationReport report = new EvaluationReport(PROMPT_VERSION, results);
        System.out.println(report.render());
        report.writeTo(Path.of("target", "eval-report-" + PROMPT_VERSION + ".txt"));

        assertThat(report.criticalFailures())
                .as("critical cases with wrong category or urgency")
                .isEmpty();
        assertThat(report.overallPassRate())
                .as("overall pass rate for prompt %s", PROMPT_VERSION)
                .isGreaterThanOrEqualTo(MIN_PASS_RATE);
    }
}
