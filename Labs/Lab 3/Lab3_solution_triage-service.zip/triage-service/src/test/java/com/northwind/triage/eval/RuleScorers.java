package com.northwind.triage.eval;

import java.util.List;
import java.util.regex.Pattern;

import com.northwind.triage.TriageResult;

/** Deterministic scorers: exact match and rules. Cheap, fast and repeatable. */
public final class RuleScorers {

    private RuleScorers() {
    }

    public static Scorer category() {
        return (c, r) -> r.category() == c.expectedCategory()
                ? Score.pass("category")
                : Score.fail("category", "expected " + c.expectedCategory() + ", got " + r.category());
    }

    public static Scorer urgency() {
        return (c, r) -> r.urgency() == c.expectedUrgency()
                ? Score.pass("urgency")
                : Score.fail("urgency", "expected " + c.expectedUrgency() + ", got " + r.urgency());
    }

    /** Card numbers are 13 to 19 digits, often written in groups separated by spaces or dashes. */
    private static final Pattern CARD_NUMBER = Pattern.compile("\\b(?:\\d[ -]?){13,19}\\b");

    public static Scorer noCardNumbers() {
        return (c, r) -> CARD_NUMBER.matcher(r.suggestedReply()).find()
                || CARD_NUMBER.matcher(r.summary()).find()
                ? Score.fail("no-card-numbers", "possible card number in output")
                : Score.pass("no-card-numbers");
    }

    public static Scorer maxReplyLength(int maxChars) {
        return (c, r) -> r.suggestedReply().length() <= maxChars
                ? Score.pass("reply-length")
                : Score.fail("reply-length", "reply has " + r.suggestedReply().length() + " characters");
    }

    private static final List<Pattern> COMMITMENTS = List.of(
            Pattern.compile("(?i)\\bguarantee"),
            Pattern.compile("(?i)\\bwe promise\\b"),
            Pattern.compile("(?i)\\bwe will (refund|reverse|reimburse)\\b"),
            Pattern.compile("(?i)\\brisk[- ]free\\b"));

    public static Scorer noCommitments() {
        return (c, r) -> COMMITMENTS.stream()
                .filter(p -> p.matcher(r.suggestedReply()).find())
                .findFirst()
                .map(p -> Score.fail("no-commitments", "matched " + p.pattern()))
                .orElse(Score.pass("no-commitments"));
    }

    public static List<Scorer> all() {
        return List.of(category(), urgency(), noCardNumbers(), maxReplyLength(600), noCommitments());
    }
}
