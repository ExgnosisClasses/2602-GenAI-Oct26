package com.northwind.triage.guard;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class PiiMaskerTest {

    private final PiiMasker masker = new PiiMasker();

    @Test
    void masksCardNumbers() {
        MaskingResult r = masker.mask("My card 4111 1111 1111 1111 was stolen.");
        assertThat(r.text()).isEqualTo("My card [CARD_NUMBER] was stolen.");
        assertThat(r.maskedTypes()).containsExactly("CARD_NUMBER");
    }

    @Test
    void masksValidSinOnly() {
        assertThat(masker.mask("My SIN is 046 454 286.").text()).isEqualTo("My SIN is [SIN].");
        // Nine digits that fail the Luhn check are left alone
        assertThat(masker.mask("Order 123 456 789 arrived.").masked()).isFalse();
    }

    @Test
    void masksAccountNumbersInEnglishAndFrench() {
        assertThat(masker.mask("Please check account 1234567 for the deposit.").text())
                .isEqualTo("Please check account [ACCOUNT_NUMBER] for the deposit.");
        assertThat(masker.mask("Mon numéro de compte 1234567 est bloqué.").text())
                .isEqualTo("Mon numéro de compte [ACCOUNT_NUMBER] est bloqué.");
        assertThat(masker.mask("Cheque details 00012-003-1234567.").text())
                .isEqualTo("Cheque details [ACCOUNT_NUMBER].");
    }

    @Test
    void masksEmailAndPhone() {
        MaskingResult r = masker.mask("Email jane.doe@example.com or call 613-555-0123.");
        assertThat(r.text()).isEqualTo("Email [EMAIL] or call [PHONE].");
        assertThat(r.maskedTypes()).containsExactlyInAnyOrder("EMAIL", "PHONE");
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "Why was I charged $2.50 on 2026-09-14 at 150 Elgin Street?",
            "I have 50,000 dollars in savings.",
            "Someone withdrew 2000 dollars from my account in Montreal."})
    void leavesOrdinaryNumbersAlone(String text) {
        MaskingResult r = masker.mask(text);
        assertThat(r.text()).isEqualTo(text);
        assertThat(r.masked()).isFalse();
    }
}
