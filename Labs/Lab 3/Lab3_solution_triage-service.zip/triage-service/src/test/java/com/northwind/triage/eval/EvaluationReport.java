package com.northwind.triage.eval;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class EvaluationReport {

    private final String promptVersion;
    private final List<CaseResult> results;

    public EvaluationReport(String promptVersion, List<CaseResult> results) {
        this.promptVersion = promptVersion;
        this.results = results;
    }

    public double overallPassRate() {
        return passRate(results);
    }

    public double passRate(String tag) {
        return passRate(results.stream().filter(r -> r.goldenCase().has(tag)).toList());
    }

    /** Critical cases must get both category and urgency right. */
    public List<CaseResult> criticalFailures() {
        return results.stream()
                .filter(r -> r.goldenCase().has("critical"))
                .filter(r -> !(r.passed("category") && r.passed("urgency")))
                .toList();
    }

    public String render() {
        StringBuilder sb = new StringBuilder();
        sb.append("%nTriage evaluation  prompt=%s  cases=%d%n".formatted(promptVersion, results.size()));
        sb.append("  Overall pass rate   %5.1f%%%n".formatted(100 * overallPassRate()));
        for (String tag : List.of("common", "tricky", "adversarial", "french", "critical")) {
            sb.append("  %-19s %5.1f%%%n".formatted(tag, 100 * passRate(tag)));
        }
        sb.append("Failing cases:%n".formatted());
        results.stream()
                .filter(r -> !r.pass())
                .forEach(r -> sb.append("  %s  %s%n".formatted(r.goldenCase().id(), r.failureDetails())));
        return sb.toString();
    }

    public void writeTo(Path file) throws IOException {
        Files.createDirectories(file.getParent());
        Files.writeString(file, render());
    }

    private static double passRate(List<CaseResult> subset) {
        if (subset.isEmpty()) {
            return 1.0;
        }
        return (double) subset.stream().filter(CaseResult::pass).count() / subset.size();
    }
}
