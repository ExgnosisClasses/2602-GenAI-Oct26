package com.northwind.triage.eval;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;

import com.northwind.triage.Category;
import com.northwind.triage.Urgency;

public final class GoldenDataset {

    private GoldenDataset() {
    }

    public static List<GoldenCase> load(String classpathLocation) {
        try {
            String content = new ClassPathResource(classpathLocation).getContentAsString(StandardCharsets.UTF_8);
            return content.lines()
                    .filter(line -> !line.isBlank() && !line.startsWith("#"))
                    .map(GoldenDataset::parse)
                    .toList();
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read " + classpathLocation, e);
        }
    }

    private static GoldenCase parse(String line) {
        String[] p = line.split("\\|", 5);
        Set<String> tags = Arrays.stream(p[1].split(","))
                .map(String::trim)
                .collect(Collectors.toUnmodifiableSet());
        return new GoldenCase(
                p[0].trim(),
                tags,
                Category.valueOf(p[2].trim()),
                Urgency.valueOf(p[3].trim()),
                p[4].trim());
    }
}
