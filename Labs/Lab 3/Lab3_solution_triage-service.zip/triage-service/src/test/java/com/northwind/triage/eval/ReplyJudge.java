package com.northwind.triage.eval;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatOptions;

import com.northwind.triage.TriageResult;

/**
 * LLM-as-judge scorer for qualities that rules cannot check reliably.
 * Uses a stronger model than the one being evaluated.
 */
public class ReplyJudge implements Scorer {

    private final ChatClient judge;
    private final String rubric;

    public ReplyJudge(ChatClient.Builder builder, String rubric) {
        this.judge = builder.build();
        this.rubric = rubric;
    }

    @Override
    public Score score(GoldenCase goldenCase, TriageResult result) {
        JudgeVerdict verdict = judge.prompt()
                .system(rubric)
                .user(u -> u.text("""
                                <customer_message>
                                {message}
                                </customer_message>

                                <suggested_reply>
                                {reply}
                                </suggested_reply>
                                """)
                        .param("message", goldenCase.message())
                        .param("reply", result.suggestedReply()))
                .options(OpenAiChatOptions.builder()
                        .model("gpt-6.1-sol")
                        .reasoningEffort("low"))
                .call()
                .entity(JudgeVerdict.class);

        return verdict.pass()
                ? Score.pass("judge")
                : Score.fail("judge", verdict.reason());
    }
}
