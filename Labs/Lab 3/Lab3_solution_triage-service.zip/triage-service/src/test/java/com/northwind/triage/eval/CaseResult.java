package com.northwind.triage.eval;

import java.util.List;
import java.util.stream.Collectors;

public record CaseResult(GoldenCase goldenCase, List<Score> scores) {

    public boolean pass() {
        return scores.stream().allMatch(Score::pass);
    }

    public boolean passed(String scorer) {
        return scores.stream().filter(s -> s.scorer().equals(scorer)).allMatch(Score::pass);
    }

    public String failureDetails() {
        return scores.stream()
                .filter(s -> !s.pass())
                .map(s -> s.scorer() + ": " + s.detail())
                .collect(Collectors.joining("; "));
    }
}
