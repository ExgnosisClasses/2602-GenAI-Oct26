package com.northwind.triage.eval;

import java.util.Set;

import com.northwind.triage.Category;
import com.northwind.triage.Urgency;

public record GoldenCase(
        String id,
        Set<String> tags,
        Category expectedCategory,
        Urgency expectedUrgency,
        String message) {

    public boolean has(String tag) {
        return tags.contains(tag);
    }
}
