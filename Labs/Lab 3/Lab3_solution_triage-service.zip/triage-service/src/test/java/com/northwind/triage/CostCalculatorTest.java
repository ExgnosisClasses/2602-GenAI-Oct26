package com.northwind.triage;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.Map;

import org.junit.jupiter.api.Test;

class CostCalculatorTest {

    private final CostCalculator calculator = new CostCalculator(new PricingProperties(Map.of(
            "gpt-6-luna", new PricingProperties.ModelPrice(
                    new BigDecimal("0.10"), new BigDecimal("0.01"), new BigDecimal("0.50")))));

    @Test
    void costsUncachedCachedAndOutputTokensSeparately() {
        // 1,000 prompt tokens of which 400 cached, 200 output tokens
        // 600 x 0.10 + 400 x 0.01 + 200 x 0.50 = 60 + 4 + 100 = 164 per million = 0.000164 USD
        BigDecimal cost = calculator.cost("gpt-6-luna", 1_000, 400, 200);
        assertThat(cost).isEqualByComparingTo("0.000164");
    }

    @Test
    void matchesDatedSnapshotNames() {
        BigDecimal cost = calculator.cost("gpt-6-luna-2026-09-22", 1_000_000, 0, 0);
        assertThat(cost).isEqualByComparingTo("0.10");
    }

    @Test
    void failsForUnknownModels() {
        assertThatThrownBy(() -> calculator.cost("unknown-model", 1, 0, 1))
                .isInstanceOf(IllegalStateException.class);
    }
}
