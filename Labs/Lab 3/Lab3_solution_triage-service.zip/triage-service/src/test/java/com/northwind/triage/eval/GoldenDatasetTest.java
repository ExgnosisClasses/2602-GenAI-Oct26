package com.northwind.triage.eval;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

class GoldenDatasetTest {

    private final List<GoldenCase> cases = GoldenDataset.load("golden/triage-golden.txt");

    @Test
    void hasTwentyFiveCasesWithUniqueIds() {
        assertThat(cases).hasSize(25);
        assertThat(cases).extracting(GoldenCase::id).doesNotHaveDuplicates();
    }

    @Test
    void coversCommonTrickyAndAdversarialCases() {
        assertThat(cases).filteredOn(c -> c.has("common")).hasSizeGreaterThanOrEqualTo(10);
        assertThat(cases).filteredOn(c -> c.has("tricky")).hasSizeGreaterThanOrEqualTo(5);
        assertThat(cases).filteredOn(c -> c.has("adversarial")).hasSizeGreaterThanOrEqualTo(5);
        assertThat(cases).filteredOn(c -> c.has("french")).hasSizeGreaterThanOrEqualTo(3);
    }
}
