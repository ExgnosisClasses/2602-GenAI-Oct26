package com.northwind.accounts;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class AccountServiceTest {

    private final AccountService service = new AccountService();

    @Test
    void returnsSummaryAndRecentTransactionsNewestFirst() {
        assertThat(service.summary("CHQ-1001").feeReversalsLast12Months()).isZero();
        assertThat(service.recentTransactions("CHQ-1001", 30))
                .extracting(Transaction::id)
                .containsExactly("T-1003", "F-2002", "T-1002", "T-1001", "F-2001");
        assertThat(service.recentTransactions("CHQ-1001", 6)).extracting(Transaction::id)
                .containsExactly("T-1003", "F-2002");
    }

    @Test
    void reversesAFeeOnceAndCountsIt() {
        service.reverseFee("CHQ-1001", "F-2002", "POL-FEE-01");

        assertThat(service.summary("CHQ-1001").feeReversalsLast12Months()).isEqualTo(1);
        assertThatThrownBy(() -> service.reverseFee("CHQ-1001", "F-2002", "again"))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void rejectsFeesFromAnotherAccountAndUnknownAccounts() {
        assertThatThrownBy(() -> service.reverseFee("CHQ-1001", "F-3001", "wrong account"))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> service.summary("CHQ-9999"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void ordersAReplacementCard() {
        assertThat(service.orderReplacementCard("CHQ-1003", "lost")).startsWith("Card blocked and replacement CO-");
        assertThat(service.summary("CHQ-1003").cardStatus()).isEqualTo("BLOCKED_REPLACEMENT_ORDERED");
    }
}
