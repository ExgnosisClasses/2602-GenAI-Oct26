package com.northwind.accounts;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.ai.mcp.annotation.McpToolParam;
import org.springframework.stereotype.Component;

/**
 * Publishes the account-servicing operations as MCP tools.
 * Read tools start with get_ or list_; the other two change account data.
 */
@Component
public class AccountMcpTools {

    private static final Logger log = LoggerFactory.getLogger(AccountMcpTools.class);

    private final AccountService accounts;

    public AccountMcpTools(AccountService accounts) {
        this.accounts = accounts;
    }

    @McpTool(name = "get_account_summary",
            description = "Get the type, status, open date, card status and number of fee reversals in the last "
                    + "12 months for one account.")
    public AccountSummary getAccountSummary(
            @McpToolParam(description = "Account reference, for example CHQ-1001", required = true) String accountRef) {
        log.info("READ get_account_summary account={}", accountRef);
        return accounts.summary(accountRef);
    }

    @McpTool(name = "list_recent_transactions",
            description = "List an account's transactions for the last N days, newest first. "
                    + "Fees have IDs that start with F-.")
    public List<Transaction> listRecentTransactions(
            @McpToolParam(description = "Account reference, for example CHQ-1001", required = true) String accountRef,
            @McpToolParam(description = "Number of days to look back, 1 to 90", required = true) int days) {
        log.info("READ list_recent_transactions account={} days={}", accountRef, days);
        return accounts.recentTransactions(accountRef, days);
    }

    @McpTool(name = "reverse_fee",
            description = "Reverse one fee on an account. Changes account data.")
    public String reverseFee(
            @McpToolParam(description = "Account reference", required = true) String accountRef,
            @McpToolParam(description = "Fee ID, for example F-2002", required = true) String feeId,
            @McpToolParam(description = "Reason for the reversal, citing the policy", required = true) String reason) {
        return accounts.reverseFee(accountRef, feeId, reason);
    }

    @McpTool(name = "order_replacement_card",
            description = "Block the current card and order a replacement. Changes account data.")
    public String orderReplacementCard(
            @McpToolParam(description = "Account reference", required = true) String accountRef,
            @McpToolParam(description = "Reason, for example lost or stolen", required = true) String reason) {
        return accounts.orderReplacementCard(accountRef, reason);
    }
}
