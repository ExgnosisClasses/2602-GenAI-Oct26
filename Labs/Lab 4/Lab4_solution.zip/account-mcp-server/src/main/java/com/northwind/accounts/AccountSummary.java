package com.northwind.accounts;

/** What a servicing agent may see about an account. No names, addresses or full card numbers. */
public record AccountSummary(
        String accountRef,
        String type,
        String status,
        String openedOn,
        String cardStatus,
        int feeReversalsLast12Months) {
}
