package com.northwind.accounts;

import java.math.BigDecimal;

/** One posted transaction. Fees have IDs starting with F- so they can be named in a reversal. */
public record Transaction(
        String id,
        String date,
        String description,
        BigDecimal amount,
        String kind,
        boolean reversed) {

    Transaction markReversed() {
        return new Transaction(id, date, description, amount, kind, true);
    }
}
