package com.northwind.triage.agent;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

import com.northwind.triage.guard.AuditLog;
import com.northwind.triage.guard.GuardrailDecision;

/** The state of one agent run: its correlation ID, the tools it called and every guardrail decision. */
public class AgentRun {

    private final String correlationId = UUID.randomUUID().toString();
    private final ServiceRequest request;
    private final AuditLog auditLog;
    private final List<String> toolCalls = new CopyOnWriteArrayList<>();
    private final List<GuardrailDecision> decisions = new CopyOnWriteArrayList<>();
    private volatile boolean flagged;

    public AgentRun(ServiceRequest request, AuditLog auditLog) {
        this.request = request;
        this.auditLog = auditLog;
    }

    public void decide(String guardrail, String decision, String detail) {
        GuardrailDecision d = new GuardrailDecision(Instant.now(), correlationId, guardrail, decision, detail);
        decisions.add(d);
        auditLog.record(d);
    }

    public void toolCalled(String name) {
        toolCalls.add(name);
    }

    public void flag() {
        flagged = true;
    }

    public String correlationId() {
        return correlationId;
    }

    public ServiceRequest request() {
        return request;
    }

    public List<String> toolCalls() {
        return List.copyOf(toolCalls);
    }

    public List<GuardrailDecision> decisions() {
        return List.copyOf(decisions);
    }

    public boolean flagged() {
        return flagged;
    }
}
