package com.northwind.triage.agent;

import org.springframework.ai.mcp.McpConnectionInfo;
import org.springframework.ai.mcp.McpToolFilter;
import org.springframework.stereotype.Component;

import io.modelcontextprotocol.spec.McpSchema;

/**
 * Decides which MCP tools are offered to the model. Only read tools (get_ and list_) pass;
 * write tools stay on the server and are called only by ActionExecutor after approval.
 */
@Component
public class ReadOnlyToolFilter implements McpToolFilter {

    @Override
    public boolean test(McpConnectionInfo connectionInfo, McpSchema.Tool tool) {
        return tool.name().startsWith("get_") || tool.name().startsWith("list_");
    }
}
