package com.northwind.triage.agent;

import java.util.List;

import com.northwind.triage.guard.GuardrailDecision;

/** What the agent endpoint returns: status, resolution, proposals, the tool trajectory and the audit trail. */
public record AgentOutcome(
        String correlationId,
        String caseId,
        AgentStatus status,
        AgentResolution resolution,
        List<PendingAction> proposals,
        List<String> toolCalls,
        List<GuardrailDecision> decisions) {
}
