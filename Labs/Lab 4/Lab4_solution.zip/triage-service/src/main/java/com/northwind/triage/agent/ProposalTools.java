package com.northwind.triage.agent;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

/**
 * The agent's only "write" tools. They record a proposal and change nothing on the account.
 * The case and account come from the ToolContext set by the application, never from the model.
 */
@Component
public class ProposalTools {

    private final PendingActionStore store;

    public ProposalTools(PendingActionStore store) {
        this.store = store;
    }

    @Tool(name = "propose_fee_reversal", description = """
            Propose reversing one fee. This does not reverse the fee: it creates a request that a staff member
            must approve. Use it only when a policy you retrieved allows the reversal.""")
    public String proposeFeeReversal(
            @ToolParam(description = "Fee ID from list_recent_transactions, for example F-2002") String feeId,
            @ToolParam(description = "Reason for the reversal, citing the policy ID") String reason,
            ToolContext context) {
        if (feeId == null || !feeId.matches("F-\\d+")) {
            throw new IllegalArgumentException("feeId must be a fee ID such as F-2002 from list_recent_transactions");
        }
        PendingAction action = store.create(value(context, "correlationId"), value(context, "caseId"),
                value(context, "accountRef"), ActionType.FEE_REVERSAL, feeId, reason);
        return "Proposal " + action.id() + " created and waiting for staff approval. Nothing has been changed yet.";
    }

    @Tool(name = "propose_card_replacement", description = """
            Propose blocking the customer's card and ordering a replacement. This does not block the card:
            it creates a request that a staff member must approve. Use it only when a policy you retrieved allows it.""")
    public String proposeCardReplacement(
            @ToolParam(description = "Reason, citing the policy ID") String reason,
            ToolContext context) {
        PendingAction action = store.create(value(context, "correlationId"), value(context, "caseId"),
                value(context, "accountRef"), ActionType.CARD_REPLACEMENT, null, reason);
        return "Proposal " + action.id() + " created and waiting for staff approval. Nothing has been changed yet.";
    }

    private static String value(ToolContext context, String key) {
        return (String) context.getContext().get(key);
    }
}
