package com.northwind.triage.agent;

public enum AgentDecision {
    /** The agent proposed an action that a staff member must approve. */
    PROPOSE_ACTION,
    /** The request is answered without changing the account. */
    NO_ACTION,
    /** A person must handle the request. */
    ESCALATE
}
