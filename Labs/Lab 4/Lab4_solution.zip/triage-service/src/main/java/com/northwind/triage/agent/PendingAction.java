package com.northwind.triage.agent;

import java.time.Instant;

/** A write action proposed by the agent, with the staff decision once it is made. */
public record PendingAction(
        String id,
        String correlationId,
        String caseId,
        String accountRef,
        ActionType type,
        String feeId,
        String reason,
        ActionStatus status,
        Instant createdAt,
        String decidedBy,
        String outcome) {

    public PendingAction decided(ActionStatus newStatus, String by, String result) {
        return new PendingAction(id, correlationId, caseId, accountRef, type, feeId, reason,
                newStatus, createdAt, by, result);
    }
}
