package com.northwind.triage.agent;

import java.util.List;

/** The agent's structured answer: its decision, a summary for staff, the policies it used and a draft reply. */
public record AgentResolution(
        AgentDecision decision,
        String summary,
        List<String> policyIds,
        String draftReply) {

    public AgentResolution withDraftReply(String reply) {
        return new AgentResolution(decision, summary, policyIds, reply);
    }
}
