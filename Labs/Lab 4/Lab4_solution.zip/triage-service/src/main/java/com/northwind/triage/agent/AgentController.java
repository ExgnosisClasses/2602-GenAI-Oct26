package com.northwind.triage.agent;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/agent/requests")
public class AgentController {

    private final BackOfficeAgent agent;

    public AgentController(BackOfficeAgent agent) {
        this.agent = agent;
    }

    @PostMapping
    public AgentOutcome handle(@RequestBody ServiceRequest request) {
        return agent.handle(request);
    }
}
