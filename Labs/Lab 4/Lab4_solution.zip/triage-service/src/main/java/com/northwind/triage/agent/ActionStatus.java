package com.northwind.triage.agent;

public enum ActionStatus {
    /** Proposed by the agent; nothing has changed yet. */
    PENDING,
    /** Approved by a staff member and carried out on the account system. */
    EXECUTED,
    /** Rejected by a staff member. */
    REJECTED,
    /** Approved, but the account system refused it. */
    FAILED
}
