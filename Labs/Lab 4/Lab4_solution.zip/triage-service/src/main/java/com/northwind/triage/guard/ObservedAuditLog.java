package com.northwind.triage.guard;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;

/**
 * Writes each guardrail decision to the audit file, as before, and also records it as a short
 * span in the current trace, so decisions appear next to the model and tool calls in Grafana.
 */
@Primary
@Component
public class ObservedAuditLog implements AuditLog {

    private final FileAuditLog file;
    private final ObservationRegistry registry;

    public ObservedAuditLog(FileAuditLog file, ObservationRegistry registry) {
        this.file = file;
        this.registry = registry;
    }

    @Override
    public void record(GuardrailDecision decision) {
        file.record(decision);
        Observation.createNotStarted("guardrail", registry)
                .contextualName("guardrail " + decision.guardrail() + " " + decision.decision())
                .lowCardinalityKeyValue("guardrail.name", decision.guardrail())
                .lowCardinalityKeyValue("guardrail.decision", decision.decision())
                .highCardinalityKeyValue("guardrail.detail", decision.detail())
                .highCardinalityKeyValue("correlation.id", decision.correlationId())
                .observe(() -> { });
    }
}
