package com.northwind.triage.agent;

public enum AgentStatus {
    /** The agent proposed one or more actions; a staff member must approve them. */
    AWAITING_APPROVAL,
    /** Answered without any change to the account. */
    NO_ACTION,
    /** Stopped by an input guardrail (denied topic or input too long). */
    BLOCKED,
    /** A person must review the case before anything is sent or done. */
    ESCALATED
}
