package com.northwind.triage.agent;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.support.ToolCallbacks;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.northwind.triage.guard.AuditLog;
import com.northwind.triage.guard.GuardrailProperties;
import com.northwind.triage.guard.InjectionHeuristics;
import com.northwind.triage.guard.InputScreen;
import com.northwind.triage.guard.MaskingResult;
import com.northwind.triage.guard.OutputCheck;
import com.northwind.triage.guard.OutputGuardrail;
import com.northwind.triage.guard.PiiMasker;
import com.northwind.triage.guard.ScreeningResult;

import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;

/**
 * The back-office operations agent. Applies the Lab 3 input guardrails, runs the tool-calling loop
 * with guarded tools, checks the draft reply, and leaves every write action for a person to approve.
 */
@Service
public class BackOfficeAgent {

    private static final String USER_TEMPLATE = """
            Case: {caseId}
            Account on this case: {accountRef}

            <service_request>
            {message}
            </service_request>
            """;

    private final ChatClient chatClient;
    private final String systemPrompt;
    private final ToolCallbackProvider mcpTools;
    private final PolicyTools policyTools;
    private final ProposalTools proposalTools;
    private final PendingActionStore store;
    private final PiiMasker piiMasker;
    private final InjectionHeuristics injectionHeuristics;
    private final InputScreen inputScreen;
    private final OutputGuardrail outputGuardrail;
    private final AuditLog auditLog;
    private final GuardrailProperties properties;
    private final ObservationRegistry observations;

    public BackOfficeAgent(ChatClient.Builder builder, ResourceLoader resourceLoader,
                           ToolCallbackProvider mcpTools, PolicyTools policyTools, ProposalTools proposalTools,
                           PendingActionStore store, PiiMasker piiMasker, InjectionHeuristics injectionHeuristics,
                           InputScreen inputScreen, OutputGuardrail outputGuardrail, AuditLog auditLog,
                           GuardrailProperties properties, ObjectProvider<ObservationRegistry> observations) {
        this.chatClient = builder.build();
        this.mcpTools = mcpTools;
        this.policyTools = policyTools;
        this.proposalTools = proposalTools;
        this.store = store;
        this.piiMasker = piiMasker;
        this.injectionHeuristics = injectionHeuristics;
        this.inputScreen = inputScreen;
        this.outputGuardrail = outputGuardrail;
        this.auditLog = auditLog;
        this.properties = properties;
        this.observations = observations.getIfAvailable(() -> ObservationRegistry.NOOP);
        try {
            this.systemPrompt = resourceLoader.getResource("classpath:prompts/agent/system.st")
                    .getContentAsString(StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public AgentOutcome handle(ServiceRequest request) {
        // One parent span per agent run; every model call, tool call and guardrail decision nests under it
        return Observation.createNotStarted("agent.request", observations)
                .contextualName("agent " + request.caseId())
                .highCardinalityKeyValue("case.id", request.caseId())
                .observe(() -> run(request));
    }

    private AgentOutcome run(ServiceRequest request) {
        AgentRun run = new AgentRun(request, auditLog);

        // 1. Input limit
        if (request.message().length() > properties.maxInputChars()) {
            run.decide("input-limit", "BLOCK", "message has " + request.message().length() + " characters");
            return finish(run, AgentStatus.BLOCKED, standard(AgentDecision.NO_ACTION, properties.fallbackReply()));
        }
        run.decide("input-limit", "PASS", "");

        // 2. PII masking
        MaskingResult masking = piiMasker.mask(request.message());
        String masked = masking.text();
        run.decide("pii-masking", masking.masked() ? "MASK" : "PASS", String.join(",", masking.maskedTypes()));

        // 3. Topic and injection screening. An agent holds tools, so injection stops the run.
        ScreeningResult screening = inputScreen.screen(masked);
        if (screening.topic().denied()) {
            run.decide("denied-topic", "BLOCK", screening.topic().name());
            return finish(run, AgentStatus.BLOCKED, standard(AgentDecision.NO_ACTION, properties.referralReply()));
        }
        run.decide("denied-topic", "PASS", screening.topic().name());
        if (injectionHeuristics.match(masked).isPresent() || screening.injectionAttempt()) {
            run.decide("prompt-injection", "ESCALATE", "agent not run");
            return finish(run, AgentStatus.ESCALATED, standard(AgentDecision.ESCALATE, properties.fallbackReply()));
        }
        run.decide("prompt-injection", "PASS", "");

        // 4. The agent loop, with every tool wrapped in a guard
        AgentResolution resolution;
        try {
            resolution = callAgent(run, masked);
        } catch (RuntimeException e) {
            run.decide("agent", "ESCALATE", e.getClass().getSimpleName());
            return finish(run, AgentStatus.ESCALATED, standard(AgentDecision.ESCALATE, properties.fallbackReply()));
        }

        // 5. Status from what actually happened: proposals stored and flags raised
        boolean proposed = !store.forCase(request.caseId()).isEmpty();
        AgentStatus status = proposed ? AgentStatus.AWAITING_APPROVAL : AgentStatus.NO_ACTION;
        if (resolution.decision() == AgentDecision.ESCALATE || run.flagged()) {
            status = AgentStatus.ESCALATED;
        }

        // 6. Output guardrail on the draft reply (no retry: a person reviews instead)
        OutputCheck check = outputGuardrail.checkReply(masked, resolution.draftReply());
        if (check.pass()) {
            run.decide("output", "PASS", "");
        } else {
            run.decide("output", "ESCALATE", check.summary());
            resolution = resolution.withDraftReply(properties.fallbackReply());
            status = AgentStatus.ESCALATED;
        }
        return finish(run, status, resolution);
    }

    private AgentResolution callAgent(AgentRun run, String maskedMessage) {
        List<ToolCallback> tools = new ArrayList<>();
        for (ToolCallback tool : mcpTools.getToolCallbacks()) {
            tools.add(new GuardedToolCallback(tool, GuardedToolCallback.Source.MCP, run, piiMasker, injectionHeuristics));
        }
        for (ToolCallback tool : ToolCallbacks.from(policyTools, proposalTools)) {
            tools.add(new GuardedToolCallback(tool, GuardedToolCallback.Source.LOCAL, run, piiMasker, injectionHeuristics));
        }

        ServiceRequest request = run.request();
        return chatClient.prompt()
                .system(systemPrompt)
                .user(u -> u.text(USER_TEMPLATE)
                        .param("caseId", request.caseId())
                        .param("accountRef", request.accountRef())
                        .param("message", maskedMessage))
                .tools(tools)
                .toolContext(Map.of(
                        "caseId", request.caseId(),
                        "accountRef", request.accountRef(),
                        "correlationId", run.correlationId()))
                // gpt-6-luna accepts function tools on Chat Completions only with reasoning effort "none"
                .options(OpenAiChatOptions.builder().reasoningEffort("none"))
                .call()
                .entity(AgentResolution.class);
    }

    private AgentOutcome finish(AgentRun run, AgentStatus status, AgentResolution resolution) {
        // 7. Required disclaimer on every reply
        AgentResolution withDisclaimer = resolution.withDraftReply(outputGuardrail.appendDisclaimer(resolution.draftReply()));
        run.decide("disclaimer", "APPLY", "");
        return new AgentOutcome(run.correlationId(), run.request().caseId(), status, withDisclaimer,
                store.forCase(run.request().caseId()), run.toolCalls(), run.decisions());
    }

    private static AgentResolution standard(AgentDecision decision, String reply) {
        return new AgentResolution(decision, "Handled by a standard response; the agent did not run.", List.of(), reply);
    }
}
