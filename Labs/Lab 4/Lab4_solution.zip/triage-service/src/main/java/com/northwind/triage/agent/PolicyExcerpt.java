package com.northwind.triage.agent;

/** One policy document returned by retrieval. */
public record PolicyExcerpt(String policyId, String title, String text) {
}
