package com.northwind.triage.agent;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

/**
 * Holds proposed actions in memory. In production this is a table in the case-management
 * or workflow system, so proposals survive restarts and appear in the staff work queue.
 */
@Component
public class PendingActionStore {

    private final Map<String, PendingAction> actions = new ConcurrentHashMap<>();
    private final AtomicInteger sequence = new AtomicInteger(1000);

    public PendingAction create(String correlationId, String caseId, String accountRef,
                                ActionType type, String feeId, String reason) {
        PendingAction action = new PendingAction("PA-" + sequence.incrementAndGet(), correlationId, caseId,
                accountRef, type, feeId, reason, ActionStatus.PENDING, Instant.now(), null, null);
        actions.put(action.id(), action);
        return action;
    }

    public Optional<PendingAction> find(String id) {
        return Optional.ofNullable(actions.get(id));
    }

    public PendingAction save(PendingAction action) {
        actions.put(action.id(), action);
        return action;
    }

    public List<PendingAction> forCase(String caseId) {
        return actions.values().stream()
                .filter(a -> a.caseId().equals(caseId))
                .sorted(Comparator.comparing(PendingAction::id))
                .toList();
    }

    public List<PendingAction> all() {
        return actions.values().stream().sorted(Comparator.comparing(PendingAction::id)).toList();
    }
}
