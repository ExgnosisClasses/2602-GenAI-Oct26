package com.northwind.triage.agent;

/**
 * A service request from the case-management system. The account reference comes from the case,
 * which was opened for an authenticated customer; it never comes from the model.
 */
public record ServiceRequest(String caseId, String accountRef, String message) {
}
