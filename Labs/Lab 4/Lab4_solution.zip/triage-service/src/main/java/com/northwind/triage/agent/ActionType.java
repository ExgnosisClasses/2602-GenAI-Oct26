package com.northwind.triage.agent;

public enum ActionType {
    FEE_REVERSAL,
    CARD_REPLACEMENT
}
