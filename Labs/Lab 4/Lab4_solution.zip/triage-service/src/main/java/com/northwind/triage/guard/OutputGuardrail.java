package com.northwind.triage.guard;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.northwind.triage.TriageResult;

/**
 * Output guardrail: deterministic brand rules first, then a model-based tone check.
 * Also applies the required disclaimer, which is added in code and never left to the model.
 */
@Component
public class OutputGuardrail {

    private static final int MAX_REPLY_CHARS = 600;

    private static final List<Pattern> COMMITMENTS = List.of(
            Pattern.compile("(?i)\\bguarantee"),
            Pattern.compile("(?i)\\bwe promise\\b"),
            Pattern.compile("(?i)\\bwe will (refund|reverse|reimburse)\\b"),
            Pattern.compile("(?i)\\brisk[- ]free\\b"));

    private final ChatClient chatClient;
    private final String toneInstructions;
    private final PiiMasker piiMasker;
    private final GuardrailProperties properties;

    public OutputGuardrail(ChatClient.Builder builder, ResourceLoader resourceLoader,
                           PiiMasker piiMasker, GuardrailProperties properties) {
        this.chatClient = builder.build();
        this.piiMasker = piiMasker;
        this.properties = properties;
        try {
            this.toneInstructions = resourceLoader.getResource("classpath:prompts/guardrails/tone-check.st")
                    .getContentAsString(StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public OutputCheck check(String maskedMessage, TriageResult result) {
        return checkReply(maskedMessage, result.suggestedReply());
    }

    /** Checks any customer-facing reply. Used by the triage pipeline and by the back-office agent (Lab 4). */
    public OutputCheck checkReply(String maskedMessage, String reply) {
        List<String> problems = new ArrayList<>();

        if (reply.length() > MAX_REPLY_CHARS) {
            problems.add("reply is " + reply.length() + " characters; the limit is " + MAX_REPLY_CHARS);
        }
        if (reply.contains("!")) {
            problems.add("reply uses exclamation marks, which the brand style does not allow");
        }
        COMMITMENTS.stream()
                .filter(p -> p.matcher(reply).find())
                .findFirst()
                .ifPresent(p -> problems.add("reply promises an outcome (" + p.pattern() + ")"));
        if (piiMasker.mask(reply).masked()) {
            problems.add("reply contains personal or account data");
        }

        // Only pay for the model-based check when the cheap rules pass
        if (problems.isEmpty()) {
            ToneVerdict verdict = toneCheck(maskedMessage, reply);
            if (!verdict.pass()) {
                problems.add("tone check failed: " + verdict.reason());
            }
        }
        return new OutputCheck(problems);
    }

    public TriageResult withDisclaimer(TriageResult result) {
        return new TriageResult(result.category(), result.urgency(), result.summary(),
                appendDisclaimer(result.suggestedReply()));
    }

    /** Appends the required disclaimer once. Applying it twice has no further effect. */
    public String appendDisclaimer(String reply) {
        if (reply.contains(properties.disclaimer())) {
            return reply;
        }
        return reply + "\n\n" + properties.disclaimer();
    }

    private ToneVerdict toneCheck(String maskedMessage, String reply) {
        return chatClient.prompt()
                .system(toneInstructions)
                .user(u -> u.text("""
                                <customer_message>
                                {message}
                                </customer_message>

                                <suggested_reply>
                                {reply}
                                </suggested_reply>
                                """)
                        .param("message", maskedMessage)
                        .param("reply", reply))
                .options(OpenAiChatOptions.builder().reasoningEffort("low"))
                .call()
                .entity(ToneVerdict.class);
    }
}
