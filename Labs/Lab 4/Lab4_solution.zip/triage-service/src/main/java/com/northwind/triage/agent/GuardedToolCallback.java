package com.northwind.triage.agent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.ai.tool.metadata.ToolMetadata;

import com.northwind.triage.guard.InjectionHeuristics;
import com.northwind.triage.guard.MaskingResult;
import com.northwind.triage.guard.PiiMasker;

/**
 * Wraps every tool the agent can call. Records the call, keeps the agent on the case's account,
 * masks personal data in results and flags injection text that arrives through a tool result.
 */
public class GuardedToolCallback implements ToolCallback {

    /** MCP tools run on the account server and do not accept a ToolContext; local tools do. */
    public enum Source { MCP, LOCAL }

    private static final Pattern ACCOUNT_REF = Pattern.compile("\"accountRef\"\\s*:\\s*\"([^\"]*)\"");

    private final ToolCallback delegate;
    private final Source source;
    private final AgentRun run;
    private final PiiMasker piiMasker;
    private final InjectionHeuristics injectionHeuristics;

    public GuardedToolCallback(ToolCallback delegate, Source source, AgentRun run,
                               PiiMasker piiMasker, InjectionHeuristics injectionHeuristics) {
        this.delegate = delegate;
        this.source = source;
        this.run = run;
        this.piiMasker = piiMasker;
        this.injectionHeuristics = injectionHeuristics;
    }

    @Override
    public ToolDefinition getToolDefinition() {
        return delegate.getToolDefinition();
    }

    @Override
    public ToolMetadata getToolMetadata() {
        return delegate.getToolMetadata();
    }

    @Override
    public String call(String toolInput) {
        return call(toolInput, null);
    }

    @Override
    public String call(String toolInput, ToolContext toolContext) {
        String name = getToolDefinition().name();
        run.toolCalled(name);

        // Tool input guardrail: the model may only read the account on this case
        Matcher account = ACCOUNT_REF.matcher(toolInput);
        if (account.find() && !account.group(1).equals(run.request().accountRef())) {
            run.decide("tool-scope", "BLOCK", name + " requested a different account");
            return "Error: tools can only be used for the account on this case.";
        }

        String result = source == Source.LOCAL
                ? delegate.call(toolInput, toolContext)
                : delegate.call(toolInput);

        // Tool output guardrails: results are untrusted data
        MaskingResult masked = piiMasker.mask(result);
        if (masked.masked()) {
            run.decide("tool-result-pii", "MASK", name + ": " + String.join(",", masked.maskedTypes()));
        }
        if (injectionHeuristics.match(masked.text()).isPresent()) {
            run.flag();
            run.decide("tool-result-injection", "FLAG", name);
        }
        return masked.text();
    }
}
