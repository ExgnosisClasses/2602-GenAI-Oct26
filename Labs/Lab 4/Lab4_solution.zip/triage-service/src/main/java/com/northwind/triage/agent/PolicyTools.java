package com.northwind.triage.agent;

import java.util.List;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

/** Retrieval exposed to the agent as a tool, so the agent decides when it needs policy. */
@Component
public class PolicyTools {

    private final PolicyLibrary library;

    public PolicyTools(PolicyLibrary library) {
        this.library = library;
    }

    @Tool(name = "search_policy", description = """
            Search Northwind Bank's servicing policies and return the two most relevant, with their IDs.
            Use it before deciding what the bank can do for the customer.""")
    public List<PolicyExcerpt> searchPolicy(
            @ToolParam(description = "What you need to know, for example: overdraft fee reversal rules") String query) {
        return library.search(query);
    }
}
