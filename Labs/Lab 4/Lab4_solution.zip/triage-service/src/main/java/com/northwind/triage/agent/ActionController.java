package com.northwind.triage.agent;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** The staff side of human approval: list proposals, approve or reject them. */
@RestController
@RequestMapping("/actions")
public class ActionController {

    public record StaffDecision(String approver, String reason) {
    }

    private final PendingActionStore store;
    private final ActionExecutor executor;

    public ActionController(PendingActionStore store, ActionExecutor executor) {
        this.store = store;
        this.executor = executor;
    }

    @GetMapping
    public List<PendingAction> list() {
        return store.all();
    }

    @PostMapping("/{id}/approve")
    public PendingAction approve(@PathVariable String id, @RequestBody StaffDecision decision) {
        return executor.approve(id, decision.approver());
    }

    @PostMapping("/{id}/reject")
    public PendingAction reject(@PathVariable String id, @RequestBody StaffDecision decision) {
        return executor.reject(id, decision.approver(), decision.reason());
    }
}
