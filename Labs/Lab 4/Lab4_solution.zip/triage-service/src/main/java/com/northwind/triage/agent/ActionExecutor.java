package com.northwind.triage.agent;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.northwind.triage.guard.AuditLog;
import com.northwind.triage.guard.GuardrailDecision;

import io.modelcontextprotocol.client.McpSyncClient;
import io.modelcontextprotocol.spec.McpSchema;

/**
 * Carries out approved actions. This is ordinary application code, outside the model loop:
 * it calls the MCP write tools directly, and only after a named staff member approves.
 */
@Service
public class ActionExecutor {

    private final PendingActionStore store;
    private final McpSyncClient accountServer;
    private final AuditLog auditLog;

    public ActionExecutor(PendingActionStore store, List<McpSyncClient> mcpClients, AuditLog auditLog) {
        this.store = store;
        this.accountServer = mcpClients.getFirst();   // one connection is configured: account-servicing
        this.auditLog = auditLog;
    }

    public PendingAction approve(String actionId, String approver) {
        PendingAction action = pending(actionId);
        requireApprover(approver);
        record(action, "approval", "APPROVE", "by " + approver);
        try {
            String result = execute(action);
            record(action, "action", "EXECUTE", result);
            return store.save(action.decided(ActionStatus.EXECUTED, approver, result));
        } catch (RuntimeException e) {
            record(action, "action", "FAIL", e.getMessage());
            return store.save(action.decided(ActionStatus.FAILED, approver, e.getMessage()));
        }
    }

    public PendingAction reject(String actionId, String approver, String reason) {
        PendingAction action = pending(actionId);
        requireApprover(approver);
        record(action, "approval", "REJECT", "by " + approver + ": " + reason);
        return store.save(action.decided(ActionStatus.REJECTED, approver, reason));
    }

    private String execute(PendingAction action) {
        McpSchema.CallToolRequest request = switch (action.type()) {
            case FEE_REVERSAL -> new McpSchema.CallToolRequest("reverse_fee", Map.of(
                    "accountRef", action.accountRef(), "feeId", action.feeId(), "reason", action.reason()));
            case CARD_REPLACEMENT -> new McpSchema.CallToolRequest("order_replacement_card", Map.of(
                    "accountRef", action.accountRef(), "reason", action.reason()));
        };
        McpSchema.CallToolResult result = accountServer.callTool(request);
        String text = result.content().stream()
                .filter(McpSchema.TextContent.class::isInstance)
                .map(c -> ((McpSchema.TextContent) c).text())
                .collect(Collectors.joining(" "));
        if (Boolean.TRUE.equals(result.isError())) {
            throw new IllegalStateException(text);
        }
        return text;
    }

    private PendingAction pending(String actionId) {
        PendingAction action = store.find(actionId)
                .orElseThrow(() -> new IllegalArgumentException("No action " + actionId));
        if (action.status() != ActionStatus.PENDING) {
            throw new IllegalStateException("Action " + actionId + " is already " + action.status());
        }
        return action;
    }

    private static void requireApprover(String approver) {
        if (approver == null || approver.isBlank()) {
            throw new IllegalArgumentException("approver is required");
        }
    }

    private void record(PendingAction action, String guardrail, String decision, String detail) {
        auditLog.record(new GuardrailDecision(Instant.now(), action.correlationId(), guardrail, decision,
                action.id() + " " + detail));
    }
}
