package com.northwind.triage.agent;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

/**
 * Loads the servicing policies from src/main/resources/policies into an in-memory vector store
 * at start-up, and answers similarity searches against them.
 */
@Component
public class PolicyLibrary {

    private final SimpleVectorStore store;

    public PolicyLibrary(EmbeddingModel embeddingModel) throws IOException {
        this.store = SimpleVectorStore.builder(embeddingModel).build();

        List<Document> documents = new ArrayList<>();
        Resource[] files = new PathMatchingResourcePatternResolver().getResources("classpath:policies/*.md");
        for (Resource file : files) {
            String text = file.getContentAsString(StandardCharsets.UTF_8);
            // First line: "# POL-FEE-01 Courtesy reversal of service fees"
            String heading = text.lines().findFirst().orElseThrow().replaceFirst("^#\\s*", "");
            String policyId = heading.substring(0, heading.indexOf(' '));
            String title = heading.substring(policyId.length() + 1);
            documents.add(new Document(text, Map.of("policyId", policyId, "title", title)));
        }
        store.add(documents);   // one embedding call for all documents
    }

    public List<PolicyExcerpt> search(String query) {
        return store.similaritySearch(SearchRequest.builder().query(query).topK(2).build()).stream()
                .map(d -> new PolicyExcerpt(
                        (String) d.getMetadata().get("policyId"),
                        (String) d.getMetadata().get("title"),
                        d.getText()))
                .toList();
    }
}
