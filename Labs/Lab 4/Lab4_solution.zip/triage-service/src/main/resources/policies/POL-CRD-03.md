# POL-CRD-03 Lost or stolen debit cards

- When a customer reports a debit card lost or stolen, block the card and order a replacement as soon as possible.
- The replacement arrives by mail in five to seven business days.
- If the customer reports transactions they did not make, also follow POL-FRD-05.
- Blocking the card and ordering a replacement is one action and must be approved by a staff member.
