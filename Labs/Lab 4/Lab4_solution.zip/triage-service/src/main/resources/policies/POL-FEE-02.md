# POL-FEE-02 Foreign transaction fees

A foreign transaction fee of 2.5 percent is charged on purchases made in a currency other than Canadian dollars.

- Foreign transaction fees are disclosed in the account agreement and are not reversed as a courtesy.
- If the customer believes the purchase itself was not theirs, handle it as a possible fraud under POL-FRD-05.
- Customers who travel often can be told that a no-foreign-fee card is available, without recommending a product.
