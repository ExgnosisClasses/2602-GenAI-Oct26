# POL-FRD-05 Suspected fraud and large disputes

- Reports of transactions the customer did not make, and disputes over 500 dollars, are handled by the fraud team.
- Do not propose reversals or credits for these cases. Escalate them so a person contacts the customer the same day.
- Tell the customer that the fraud team will contact them and that they should not share passwords or codes with anyone.
