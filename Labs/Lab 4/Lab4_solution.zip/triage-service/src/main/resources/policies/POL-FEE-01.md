# POL-FEE-01 Courtesy reversal of service fees

Applies to overdraft fees, NSF (non-sufficient funds) fees and ATM fees on personal chequing accounts.

- Staff may reverse one service fee per account in any 12-month period as a courtesy.
- The account must be ACTIVE, the fee must be 50 dollars or less, and it must have been charged in the last 60 days.
- An account that already had one or more fee reversals in the last 12 months is not eligible. Explain that the
  courtesy reversal has already been used and offer a review of the account's package and overdraft options.
- Foreign transaction fees are covered by POL-FEE-02.
- Every reversal must be approved by a staff member and must cite this policy.
