# POL-ADR-04 Change of address

- An address change cannot be made from a message or an email, because the sender's identity has not been verified.
- Ask the customer to change the address in online banking, in the mobile app, or at a branch with photo identification.
- Do not repeat the new address in the reply.
