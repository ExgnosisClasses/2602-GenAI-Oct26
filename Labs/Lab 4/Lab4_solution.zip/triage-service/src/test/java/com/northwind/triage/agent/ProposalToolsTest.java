package com.northwind.triage.agent;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ToolContext;

class ProposalToolsTest {

    private final PendingActionStore store = new PendingActionStore();
    private final ProposalTools tools = new ProposalTools(store);
    private final ToolContext context = new ToolContext(Map.of(
            "caseId", "C-1", "accountRef", "CHQ-1001", "correlationId", "corr-1"));

    @Test
    void createsAPendingProposalForTheCaseAccount() {
        String reply = tools.proposeFeeReversal("F-2002", "POL-FEE-01 first courtesy reversal", context);

        assertThat(reply).contains("PA-1001").contains("Nothing has been changed");
        assertThat(store.forCase("C-1")).singleElement().satisfies(a -> {
            assertThat(a.status()).isEqualTo(ActionStatus.PENDING);
            assertThat(a.type()).isEqualTo(ActionType.FEE_REVERSAL);
            assertThat(a.accountRef()).isEqualTo("CHQ-1001");   // taken from the ToolContext
            assertThat(a.correlationId()).isEqualTo("corr-1");
        });
    }

    @Test
    void rejectsAnIdThatIsNotAFee() {
        assertThatThrownBy(() -> tools.proposeFeeReversal("T-1002", "not a fee", context))
                .isInstanceOf(IllegalArgumentException.class);
        assertThat(store.all()).isEmpty();
    }
}
