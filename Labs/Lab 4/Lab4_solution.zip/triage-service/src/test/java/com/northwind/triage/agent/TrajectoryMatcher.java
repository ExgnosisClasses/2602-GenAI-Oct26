package com.northwind.triage.agent;

import java.util.Iterator;
import java.util.List;

/** Compares the tools an agent called with the tools a scenario expects. */
final class TrajectoryMatcher {

    enum Match {
        /** The same calls, in the same order, with nothing extra. */
        EXACT,
        /** The expected calls appear in this order; other calls may come in between. */
        IN_ORDER,
        /** All expected calls appear, in any order; other calls are allowed. */
        ANY_ORDER
    }

    private TrajectoryMatcher() {
    }

    static boolean matches(List<String> actual, List<String> expected, Match match) {
        return switch (match) {
            case EXACT -> actual.equals(expected);
            case ANY_ORDER -> actual.containsAll(expected);
            case IN_ORDER -> {
                Iterator<String> calls = actual.iterator();
                yield expected.stream().allMatch(step -> {
                    while (calls.hasNext()) {
                        if (calls.next().equals(step)) {
                            return true;
                        }
                    }
                    return false;
                });
            }
        };
    }
}
