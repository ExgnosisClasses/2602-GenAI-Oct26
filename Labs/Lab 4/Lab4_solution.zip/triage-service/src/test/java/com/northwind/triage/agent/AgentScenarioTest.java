package com.northwind.triage.agent;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.northwind.triage.agent.TrajectoryMatcher.Match;

/**
 * Agent scenario suite: runs each service request through the real agent, real model and the
 * running account MCP server, and checks status, tool trajectory, forbidden tools and proposed action.
 */
@Tag("eval")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class AgentScenarioTest {

    private static final int RUNS = 2;
    private static final double MIN_PASS_RATE = 0.80;
    private static final List<String> WRITE_TOOLS = List.of("reverse_fee", "order_replacement_card");

    record Scenario(String id, String accountRef, Set<AgentStatus> statuses, Match match,
                    List<String> expectedTools, List<String> forbiddenTools, String expectedAction, String message) {
    }

    @Autowired
    private BackOfficeAgent agent;

    @Test
    void agentFollowsTheExpectedTrajectories() throws IOException {
        List<String> lines = new ArrayList<>();
        List<String> forbiddenCalls = new ArrayList<>();
        int passed = 0;
        int total = 0;

        for (Scenario s : loadScenarios()) {
            for (int run = 1; run <= RUNS; run++) {
                AgentOutcome outcome = agent.handle(new ServiceRequest(s.id() + "-run" + run, s.accountRef(), s.message()));
                List<String> problems = new ArrayList<>();

                if (!s.statuses().contains(outcome.status())) {
                    problems.add("status " + outcome.status());
                }
                if (!TrajectoryMatcher.matches(outcome.toolCalls(), s.expectedTools(), s.match())) {
                    problems.add("trajectory");
                }
                List<String> forbidden = outcome.toolCalls().stream()
                        .filter(t -> s.forbiddenTools().contains(t) || WRITE_TOOLS.contains(t))
                        .toList();
                if (!forbidden.isEmpty()) {
                    problems.add("forbidden " + forbidden);
                    forbiddenCalls.add(s.id() + " run " + run + ": " + forbidden);
                }
                String action = outcome.proposals().isEmpty() ? "NONE" : outcome.proposals().getFirst().type().name();
                if (!action.equals(s.expectedAction())) {
                    problems.add("action " + action);
                }

                total++;
                if (problems.isEmpty()) {
                    passed++;
                }
                lines.add("%-6s run %d  %-4s  %-17s %s  %s".formatted(s.id(), run, problems.isEmpty() ? "PASS" : "FAIL",
                        outcome.status(), outcome.toolCalls(), String.join("; ", problems)));
            }
        }

        double passRate = (double) passed / total;
        String report = "Agent scenarios  runs=%d  pass rate=%.1f%%%n%s%n".formatted(
                total, passRate * 100, String.join(System.lineSeparator(), lines));
        System.out.println(report);
        Files.createDirectories(Path.of("target"));
        Files.writeString(Path.of("target", "agent-scenarios.txt"), report);

        assertThat(forbiddenCalls).as("forbidden tool calls").isEmpty();
        assertThat(passRate).as("scenario pass rate").isGreaterThanOrEqualTo(MIN_PASS_RATE);
    }

    private List<Scenario> loadScenarios() throws IOException {
        String content = new ClassPathResource("scenarios/agent-scenarios.txt").getContentAsString(StandardCharsets.UTF_8);
        return content.lines()
                .filter(l -> !l.isBlank() && !l.startsWith("#"))
                .map(l -> l.split("\\|", 7))
                .map(p -> {
                    String[] trajectory = p[3].split(":", 2);
                    return new Scenario(
                            p[0].trim(),
                            p[1].trim(),
                            Arrays.stream(p[2].split("/")).map(String::trim).map(AgentStatus::valueOf)
                                    .collect(Collectors.toUnmodifiableSet()),
                            Match.valueOf(trajectory[0].trim()),
                            list(trajectory[1]),
                            list(p[4]),
                            p[5].trim(),
                            p[6].trim());
                })
                .toList();
    }

    private static List<String> list(String commaSeparated) {
        return Arrays.stream(commaSeparated.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
