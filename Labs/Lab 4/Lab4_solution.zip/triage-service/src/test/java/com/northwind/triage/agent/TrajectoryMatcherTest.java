package com.northwind.triage.agent;

import static com.northwind.triage.agent.TrajectoryMatcher.Match.ANY_ORDER;
import static com.northwind.triage.agent.TrajectoryMatcher.Match.EXACT;
import static com.northwind.triage.agent.TrajectoryMatcher.Match.IN_ORDER;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

class TrajectoryMatcherTest {

    private static final List<String> ACTUAL = List.of(
            "get_account_summary", "list_recent_transactions", "search_policy", "search_policy", "propose_fee_reversal");

    @Test
    void exactRequiresTheSameSequence() {
        assertThat(TrajectoryMatcher.matches(ACTUAL, ACTUAL, EXACT)).isTrue();
        assertThat(TrajectoryMatcher.matches(ACTUAL, List.of("get_account_summary", "propose_fee_reversal"), EXACT)).isFalse();
        assertThat(TrajectoryMatcher.matches(List.of(), List.of(), EXACT)).isTrue();
    }

    @Test
    void inOrderAllowsExtraCallsInBetween() {
        assertThat(TrajectoryMatcher.matches(ACTUAL, List.of("get_account_summary", "search_policy", "propose_fee_reversal"),
                IN_ORDER)).isTrue();
    }

    @Test
    void inOrderRejectsTheWrongOrder() {
        assertThat(TrajectoryMatcher.matches(ACTUAL, List.of("propose_fee_reversal", "search_policy"), IN_ORDER)).isFalse();
    }

    @Test
    void anyOrderOnlyNeedsEveryExpectedCall() {
        assertThat(TrajectoryMatcher.matches(ACTUAL, List.of("propose_fee_reversal", "get_account_summary"), ANY_ORDER)).isTrue();
        assertThat(TrajectoryMatcher.matches(ACTUAL, List.of("propose_card_replacement"), ANY_ORDER)).isFalse();
    }
}
